#!/bin/bash
osascript -e 'tell app "Terminal" to do script "bash ~/minishell/test_leak.sh"'
