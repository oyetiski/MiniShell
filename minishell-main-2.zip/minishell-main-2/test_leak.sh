#!/bin/bash
while [[ True ]]; do
	leaks minishell
done
